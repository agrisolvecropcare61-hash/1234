/* =====================================================================
   APP SETTINGS - badhi settings aa file ma j change karo
   ===================================================================== */
window.APP_CONFIG = {

  // Owner PIN: price edit karva mate. Tamaru pasandnu 4-6 digit PIN mukho.
  OWNER_PIN: "1234",

  COMPANY: {
    name: "AGRI SOLVE CROP CARE",
    mobile: "8320971610"          // Owner copy WhatsApp par aa number par jase
  },

  GST_RATE: 18,                   // GST %

  /* ---------------------------------------------------------------
     FIREBASE (free) - optional, pan prices badha phone ma sync karva mate jaruri.
     Khali chhodo to app fakt aa j phone ma prices save karse.

     Steps:
     1. https://console.firebase.google.com par "Add project" karo
     2. Build > Realtime Database > "Create database" (test mode)
     3. Project settings > Your apps > Web (</>) > app register karo
     4. Dekhaatu config ni values niche FIREBASE ma paste karo
  --------------------------------------------------------------- */
  FIREBASE: {
    apiKey: "",
    authDomain: "",
    databaseURL: "",              // e.g. "https://your-project-default-rtdb.firebaseio.com"
    projectId: "",
    appId: ""
  }
};
