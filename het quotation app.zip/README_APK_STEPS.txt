AGRI SOLVE CROP CARE - QUOTATION APP (v2)
==========================================

A) SETTINGS (www/config.js)
  - OWNER_PIN      : price edit PIN (default 1234 - change karo)
  - COMPANY.mobile : owner copy WhatsApp number
  - GST_RATE       : 18

B) PRICES SYNC ON ALL PHONES (optional but recommended - free)
  1. https://console.firebase.google.com -> Add project
  2. Build -> Realtime Database -> Create database (test mode)
  3. Project settings -> Your apps -> Web (</>) -> register app
  4. Copy the config values into www/config.js -> FIREBASE { ... }
     (databaseURL is required). Save, then rebuild the APK.
  Without this, edited prices stay only on the phone where they were changed.
  Note: Firebase "test mode" rules expire after 30 days - re-enable from the Rules tab.

C) BUILD THE APK WITHOUT A PC (free, ~5 minutes)
  1. Create a free account at github.com and make a new repository.
  2. Upload ALL files from this ZIP (keep the .github, www and android-res folders).
  3. Open the "Actions" tab -> "Build APK" -> wait until it turns green.
  4. Open the finished run -> Artifacts -> download "AgriSolve-APK" -> unzip -> app-debug.apk.
  5. Send app-debug.apk to your phone and install (allow "Install unknown apps").

D) USE
  - Price List: all 143 products (Insecticide, Fungicide, Herbicide, PGR, Granule, Bio).
  - Edit Price: PIN -> change price -> Save.
  - Add Product -> search -> select -> pack size -> quantity. Total updates live.
  - PDF: generates multi-page PDF (Page 1: Customer Details + Products, Page 2: PAN Card, Page 3: Aadhar Card).
  - Share: choose Customer copy (no documents) or Owner copy (with PAN/Aadhar).
  - The app needs internet once to load (html2canvas / jsPDF / Firebase from CDN).
